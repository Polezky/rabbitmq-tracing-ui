import{default as t}from"../entry/error.svelte.da97bbf9.js";export{t as component};
