import{default as t}from"../entry/_layout.svelte.06acb561.js";export{t as component};
