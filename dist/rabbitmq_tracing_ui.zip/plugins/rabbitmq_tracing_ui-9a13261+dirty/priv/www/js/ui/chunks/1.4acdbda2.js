import{default as t}from"../entry/error.svelte.186ad7b0.js";export{t as component};
