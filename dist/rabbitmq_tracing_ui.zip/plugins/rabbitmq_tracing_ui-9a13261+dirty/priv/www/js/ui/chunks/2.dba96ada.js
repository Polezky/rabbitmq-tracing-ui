import{default as t}from"../entry/_page.svelte.3b0436a5.js";export{t as component};
