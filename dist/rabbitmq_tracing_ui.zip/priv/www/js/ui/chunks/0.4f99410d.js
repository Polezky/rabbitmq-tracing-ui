import{default as t}from"../entry/_layout.svelte.70b47209.js";export{t as component};
