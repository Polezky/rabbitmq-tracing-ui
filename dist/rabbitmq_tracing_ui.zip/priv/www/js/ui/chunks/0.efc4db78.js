import{default as t}from"../entry/_layout.svelte.7808d520.js";export{t as component};
