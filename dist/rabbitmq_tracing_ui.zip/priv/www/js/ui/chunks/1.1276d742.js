import{default as t}from"../entry/error.svelte.b9f75dcc.js";export{t as component};
