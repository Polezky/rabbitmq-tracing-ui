import{default as t}from"../entry/error.svelte.15492790.js";export{t as component};
