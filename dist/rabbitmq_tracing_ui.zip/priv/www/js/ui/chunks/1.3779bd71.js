import{default as t}from"../entry/error.svelte.f1aa7387.js";export{t as component};
