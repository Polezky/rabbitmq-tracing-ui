import{default as t}from"../entry/error.svelte.489c7cb4.js";export{t as component};
