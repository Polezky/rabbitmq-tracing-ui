import{default as t}from"../entry/error.svelte.d34c5743.js";export{t as component};
