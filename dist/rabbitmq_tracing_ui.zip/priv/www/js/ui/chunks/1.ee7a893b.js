import{default as t}from"../entry/error.svelte.bc3ffd77.js";export{t as component};
