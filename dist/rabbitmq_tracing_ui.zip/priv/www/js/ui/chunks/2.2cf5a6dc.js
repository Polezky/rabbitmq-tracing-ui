import{default as t}from"../entry/_page.svelte.87a89015.js";export{t as component};
