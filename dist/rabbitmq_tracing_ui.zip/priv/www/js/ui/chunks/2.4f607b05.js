import{default as t}from"../entry/_page.svelte.c0da72e6.js";export{t as component};
