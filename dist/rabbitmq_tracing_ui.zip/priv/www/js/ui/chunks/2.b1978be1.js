import{default as t}from"../entry/_page.svelte.915438f0.js";export{t as component};
