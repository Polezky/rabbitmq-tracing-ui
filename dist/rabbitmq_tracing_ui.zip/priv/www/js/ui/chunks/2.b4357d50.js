import{default as t}from"../entry/_page.svelte.b2202384.js";export{t as component};
