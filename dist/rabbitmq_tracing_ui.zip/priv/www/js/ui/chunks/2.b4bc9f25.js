import{default as t}from"../entry/_page.svelte.68a69c8c.js";export{t as component};
