import{default as t}from"../entry/_page.svelte.a5729c5a.js";export{t as component};
